//#![deny(warnings)]
//#![deny(unused_imports)]


/**
 * (c) Incomplete Worlds 2020 
 * Alberto Fernandez (ajfg)
 * 
 * FDS as a Service main
 * It will implement the entry point and the REST API
 */


use std::env;
use std::thread;
use std::time::Duration;
use std::sync::mpsc;
// use std::sync::mpsc::channel;
// use std::collections::HashMap;
//use std::error::Error;
//use std::collections::BTreeMap;
use std::result::Result;

// Serialize/Deserialize; YAML, JSON
//use serde::{Serialize, Deserialize};
use serde_json::{Value};

// Log 
use log::{debug, error, info, trace, warn};
use log::{LevelFilter, SetLoggerError};
use log4rs::append::console::{ConsoleAppender, Target};
use log4rs::append::file::FileAppender;
use log4rs::config::{Appender, Config, Root};
use log4rs::encode::pattern::PatternEncoder;
use log4rs::filter::threshold::ThresholdFilter;

// Date & Time
use chrono::{DateTime, Utc};

// Actix Web Server
use actix_web::{web, App, HttpResponse, HttpServer, Responder, HttpRequest /*middleware*/};
use actix_files as fs;
//use actix_files::{ NamedFile };
// use actix_identity::{CookieIdentityPolicy, IdentityService};
use actix_rt::System;
use actix_web::dev::Server;

// New Nanomsg
use nng::options::{Options, Raw};
use nng::*;

// Messages
mod fds_messages;
use fds_messages::*;
//use fds_messages::{ApiMessage, build_api_message, build_api_message_str, build_api_answer, build_api_answer_str, build_api_answer_str_json};

mod authorization_manager;
use authorization_manager::check_authorization;

mod modules_manager;
use modules_manager::*;

// Common functions
mod common;
use common::{ read_config_json, config_log, ConfigVariables };




// limit the maximum amount of data that server will accept
const MAX_SIZE_JSON : usize =  262_144;

const FDSAAS_VERSION : &str = "0.1";

#[derive(Clone)]
enum EnumStatus {
    NONE,
    RUNNING,
    STOPPED,
}

impl EnumStatus {
    fn to_string(&self) -> String {
        match *self {
            EnumStatus::NONE     => String::from("None"),
            EnumStatus::RUNNING  => String::from("Running"),
            EnumStatus::STOPPED  => String::from("Stopped"),
        }
    }
}

struct GlobalData {
    fds_status:             EnumStatus,
    nng_ip_address:         String,
    exit_flag:              bool,
}

// Store the Global Data in the Head
static mut GLOBAL_DATA : GlobalData = GlobalData {
    fds_status :           EnumStatus::NONE,
    nng_ip_address :       String::new(),
    exit_flag :            false, 
};





//
// ====================================================================
// ====================================================================
// 

/**
 * It does receives messages from the HTTP thread and send the replies back to
 * HTTP
 */
fn main_control_loop(in_config_variables: ConfigVariables, in_nng_address: String) {
    info!("**** Starting MAIN control loop ");

    // Create the Module Manager
    let mut module_manager = ModuleManager::init();
    info!("Module Manager created");

    // Load Module definitions
    // Start executing the modules
    if let Err(_e) = module_manager.load_module_definitions(&in_config_variables) {
        return;
    } else {
        info!("Module definitions correctly loaded");
    }
    
    // Create Socket
    let rep_control_socket = Socket::new(Protocol::Rep0);
    let rep_control_socket   = match rep_control_socket  {
        Ok(s) =>  { info!("Socket to FDS server correctly created ");
                    s
        },
        Err(e) => {
            error!("Unable to create main control REP socket. Error: {}", e.to_string());
            return;
        },
    };

    // Start listening
    let unused_result = rep_control_socket.listen( in_nng_address.as_str() );
    if let Err(e) = unused_result {
        error!("Error when starting listening the socket: {}", e );
        return;
    }
    info!("Correctly connected to Main Control (REP). Address: {}", in_nng_address);

    let mut done_flag = false;
    let mut output_json_message : String = String::new();

    while done_flag == false {
        unsafe {
            if GLOBAL_DATA.exit_flag == true {
                done_flag = true;
                debug!("MAIN loop exiting");
                continue;
            }
        }

        // Read a message
        // ------------------------------------------
        // This code shall be used when nanomsg socket is being used
        let input_msg = rep_control_socket.recv();
        //debug!("Received message: {}", input_msg.unwrap().as_slice() );
        
        if let Err(e) = input_msg {
            error!("Error when receiving a message: {}", e );
            // End of the loop
            break;
        }
        
        // As u8[]
        let json_buffer = input_msg.unwrap();

        debug!("Received message: {}", String::from_utf8( json_buffer.as_slice().to_vec()).unwrap() );

        // Decode JSON
        let json_message = serde_json::from_slice(json_buffer.as_slice());
        // let json_message : ApiMessage  = match json_message {
        let json_message : Value = match json_message {
            Ok(msg) => msg,
            Err(e) => {
                let tmp_msg = format!("ERROR: Unable to decode JSON message: {}. IGNORED", e.to_string());
                error!("{}", tmp_msg.as_str() );
                let resp_json_message = build_api_answer_str_json(true, tmp_msg.as_str(), "");
                
                let socket_m = nng::Message::from(resp_json_message.as_bytes());
                
                rep_control_socket.send(socket_m).expect("Unable to send answer message");
                continue;
            },
        };

        // Stop FDS server???
        //if json_message.msg_code_id == String::from("exit") {
        if json_message["msg_code_id"] == String::from("exit") {
            // Decode the rest of the message
            // let exit_json_message  = serde_json::from_str( json_message.msg_json.as_str() );
            // let exit_json_message : ExitMessage = match exit_json_message {
            //     Ok(msg) => msg,
            //     Err(e) => {
            //         let tmp_msg = format!("ERROR: Incorrect Exit message. Error: {}", e.to_string());
            //         error!("{}", tmp_msg.as_str() );
                   
            //         let resp_json_message = build_api_answer_str_json(true, tmp_msg.as_str(), "");
                    
            //         let socket_m = nng::Message::from(resp_json_message.as_bytes());
                    
            //         rep_control_socket.send(socket_m).expect("Unable to send answer message");
            //         continue;
            //     },
            // };

            //if exit_json_message.exit_code == String::from("XYZZY") {
            if json_message["exit_code"] == String::from("XYZZY") {
                done_flag = true;

                unsafe {
                    GLOBAL_DATA.exit_flag = true;
                    debug!("Main. Leaving");
                };

                // Send back the answer
                output_json_message = build_api_answer_str_json(false, "", "");
            }
        }
        else
        {
            // Process message
            let response_message = process_message(&mut module_manager, &json_message);

            output_json_message = match response_message {
                Ok(msg) => {
                    let resp_json_message = build_api_answer_str_json(false, msg.as_str(), "");

                    resp_json_message
                },

                Err(e) => {
                    let tmp_msg = format!("ERROR: Processing JSON message: {}. IGNORED", e.to_string());
                    error!("{}", tmp_msg.as_str() );
                    let resp_json_message = build_api_answer_str_json(true, tmp_msg.as_str(), "");

                    resp_json_message
                },
            };
        }

        // Send back the answer
        let socket_m = nng::Message::from(output_json_message.as_bytes());

        // TODO: Process errors
        rep_control_socket.send(socket_m).unwrap();
    }

    // Shutting down the server
    //rep_control_socket.close();

    info!("**** Stopping MAIN control loop ");
}

//fn process_message(in_module_manager : &mut ModuleManager, in_json_message: &ApiMessage) -> Result<String, String> {
fn process_message(in_module_manager : &mut ModuleManager, in_json_message: &Value) -> Result<String, String> {
    // Create a separated thread and process the message
    //let handle = thread::spawn(|| {
        // Check Authorization
        let tmp_auth_key = String::from( in_json_message["authentication_key"].as_str().unwrap() );
        //if check_authorization( &in_json_message.authentication_key ).unwrap() == false {
        //if check_authorization( &tmp_auth_key ).unwrap() == false {
        if let Err(e) = check_authorization( &tmp_auth_key ) {
            error!("Non authorized");
            return Ok( String::from("Not authorized") );
        } 
        
        // Check license type or demo

        // Record the IP, user, etc for statistics purposes
        
        
        // Process the message based on its code
        process_a_message(in_module_manager, in_json_message)
        
    
    //});

    //let final_error = handle.join();
    
    //if let Err(e) = final_error {
    //    error!("Error processing the message: {:?}", e);
    //}

    //Ok(())
}

//fn process_a_message(in_module_manager : &mut ModuleManager, in_json_message: &ApiMessage) -> Result<String, String> {
fn process_a_message(in_module_manager : &mut ModuleManager, in_json_message: &Value) -> Result<String, String> {
    // let tmp_code_id = in_json_message["msg_code_id"].as_str().unwrap();
    
    //debug!("Received message code: {}", in_json_message.msg_code_id);
    debug!("Received message code: {}", in_json_message["msg_code_id"].as_str().unwrap() );

    match in_json_message["msg_code_id"].as_str() {
        Some("test") => {
            println!("This is a test");
        },

        // === HTTP MESSAGES ==========================

        /*
         * Orbit Propagation 
         * 
         * Check that the user has an account
         * Parameters:
         *  - username. Account user name
         *  - password. Hash encoded (SHA1 256)
         * 
         * It will read the User details from the DB
         * Encode the password read from the DB with SHA1 256
         * If both password match, then it will grant access to the API
         *   It will create the JWT and return it
         * 
         * If OK, it will return a JWT token with an expiration date of 1 day
         * If not, it will return an error
         */
        Some("orb_propagation") => {
            // TODO fix the error handling
            in_module_manager.call_module(&in_json_message).unwrap();
        },

        // === INTERNAL MESSAGES ==========================
        /*
         * Process the answer from the module 
         */      
        Some("sub_orb_propagation_answer") => {
            // TODO fix the error handling
            in_module_manager.handle_module_answer(&in_json_message).unwrap();
        },

        _ => { println!("Unknown message code: {}", in_json_message["msg_code_id"].as_str().unwrap() );
               //error!("Unknown message code: {}. IGNORED", in_json_message.msg_code_id);
               error!("Unknown message code: {}. IGNORED", in_json_message["msg_code_id"].as_str().unwrap());
             }
    };

    Ok( String::from("No error") )
}


fn dbus_control_loop(in_config_variables: ConfigVariables, in_nng_address: String) {
    info!("**** Starting DBUS control loop ");

    // Create Socket
    let bus_control_socket = Socket::new(Protocol::Bus0);
    let bus_control_socket = match bus_control_socket  {
        Ok(s) =>  { info!("Socket BUS to FDS server correctly created ");
                    s
        },
        Err(e) => {
            error!("Unable to create FDS BUS socket. Error: {}", e.to_string());
            return;
        },
    };

    // Start listening
    let unused_result = bus_control_socket.listen( in_nng_address.as_str() );
    if let Err(e) = unused_result {
        error!("Error when starting listening the socket: {}", e );
        return;
    }
    info!("Correctly connected to FDS BUS. Address: {}", in_nng_address);

    // Set socket timeout
    bus_control_socket.set_opt::<nng::options::RecvTimeout>( Some(Duration::from_millis(100)) ).unwrap(); 

    let mut done_flag = false;

    while done_flag == false {
        unsafe {
            if GLOBAL_DATA.exit_flag == true {
                done_flag = true;
                debug!("DBUS loop exiting");
                continue;
            }
        }

        // Read a message
        // ------------------------------------------
        // This code shall be used when nanomsg socket is being used
        let input_msg = bus_control_socket.recv();
        //debug!("Received message: {}", input_msg.unwrap().as_slice() );
        
        if let Err(e) = input_msg {
            // If it is not a timeout, process the error
            if e != Error::TimedOut {
                error!("Error when receiving a message: {}", e );
                // End of the loop
                break;
            }
        } else {
            // As u8[]
            let json_buffer = input_msg.unwrap();
    
    
            debug!("Received message: {}", String::from_utf8( json_buffer.as_slice().to_vec()).unwrap() );
    
            // Forward the message to the main control loop as a REQ/REP
            let payload = String::from_utf8( json_buffer.as_slice().to_vec()).unwrap();
            forward_message_internal(&payload).unwrap();

            // Ignore the answer
        }
        
        // Small sleep
        thread::sleep(Duration::from_millis(100));
    }

    info!("**** Stopping DBUS control loop ");
}

// Main web page
/**
 * Read the WebContent index.html page and return it
 */
// async fn index() -> impl Responder {


// let path: PathBuf = req.match_info().query("filename").parse().unwrap();
// Ok(NamedFile::open(path)?)

// //let f = fs::Files::new("/", "WebContent").index_file("index.html");
// //return HttpResponse::Ok().body(   );
// return HttpResponse::Ok().body("FDS as a Service\n\nIncomplete Worlds (c) 2020");
// }


// async fn index(req: HttpRequest) -> actix_web::Result<fs::NamedFile> {
// //async fn index(req: HttpRequest) -> impl Responder {
//     info!("   *** Index");

//     //let f = fs::Files::new("/", "WebContent").index_file("index.html");

//     //let path: PathBuf = req.match_info().query("filename").parse().unwrap();
//     //Ok( NamedFile::open( path )? )

//     // response
//     // Ok(HttpResponse::build( StatusCode::OK)
//     //     .content_type("text/html; charset=utf-8")
//     //     .body( HttpResponse::include_str!("../static/welcome.html")) )


//     // return HttpResponse::build( StatusCode::OK)
//     //     .content_type("text/html; charset=utf-8")
//        // .body( include_str!("../static/welcome.html"));
//     Ok ( fs::NamedFile::open("../WebContext/index.html")? )
// }


/**
 * Return the status of the FDS module
 * Status can be; None, Running, Stopped
 */
async fn get_status() -> impl Responder {
    info!("   *** Get Status");

    let tmp_status;

    unsafe {
        tmp_status = GetStatusMessageResponse {
            status: GLOBAL_DATA.fds_status.to_string(),
        };
    }

    return HttpResponse::Ok().json( tmp_status );
}

/**
 * Return the current version of the API
 */
async fn get_version() -> impl Responder {
    info!("   *** Get Version");

    // Read-only. So, it should be fine
    let tmp_version = GetVersionMessageResponse { version : FDSAAS_VERSION.to_string(), };

    return HttpResponse::Ok().json( tmp_version );
}

/**
 * Return the descrption of the selected operation.actix_files
 * It describes how to use the operation
 */
async fn api_usage(in_operation : web::Path<String>) -> impl Responder {
    info!("   *** Get API Usage");

    let mut  usage_msg : String;

    match in_operation.as_str() {
        "register" => {
            usage_msg = String::from("Register a new user");
        },

        "create_mission" => {
            usage_msg = String::from("Create a new Mission");
        },

        "create_satellite" => {
            usage_msg = String::from("Create a new Satellite associated to a mission");
        },

        "create_ground_station" => {
            usage_msg = String::from("Create a new Ground Station");
        },

        "orb_propagation" => {
            usage_msg = String::from("Orbit Propagation \n");
            usage_msg.push_str("Parameters: \n");
            usage_msg.push_str("  start_time = Start time");
        },

        _ => { 
            usage_msg = format!("Unknown operation name: {}", in_operation);
        }
    };

    let resp_json_message = build_api_answer_str_json(false, "", usage_msg.as_str());

    return HttpResponse::Ok().json( resp_json_message );
}



fn forward_message_internal(in_payload: &String) -> Result<String, String> {
    // Create Socket
    let tmp_control_socket = Socket::new(Protocol::Req0);
    let tmp_control_socket = match tmp_control_socket  {
        Ok(s) =>  { 
            info!("Socket to Main Control correctly created ");
            s
        },
        Err(e) => {
            error!("Unable to create Main Control REP socket. Error: {}", e.to_string());
            return Err( String::from("Error forwarding message to Main Control loop") );
        },
    };

    let controller_address;

    unsafe {
        controller_address = GLOBAL_DATA.nng_ip_address.clone();
    }

    // Start listening
    let unused_result = tmp_control_socket.dial( controller_address.as_str() );
    if let Err(e) = unused_result {
        error!("Error when starting listening the socket: {}", e );
        return Err( String::from("Error forwarding message to Main Control loop") );
    }
    info!("Correctly connected to Main Control server. Address: {}", controller_address);


    // Send to main control loop
    let tmp_message = Message::from(in_payload.as_bytes());


    // Send the message to the main control loop
    // Message is a JSON
    debug!("FORWARD sending message: {}", in_payload );

    let status = tmp_control_socket.send(tmp_message);
    if let Err(e) = status {
        error!("Error sending HTTP request to the Main Control: {:?}", e );
        return Err( String::from("Error sending message to Main Control loop") );
    }


    // Receive the answer and process it
    // Message is a JSON
    let tmp_output = tmp_control_socket.recv().unwrap().as_slice().to_vec();

    let http_output = String::from_utf8(tmp_output).unwrap();
    debug!("FORWARD received message: {}", http_output);

    return Ok( http_output );
}


/**
 * Forward a message to the main control loop and wait for the answer
 */
async fn forward_message(in_payload: String) -> impl Responder {

    let http_output = forward_message_internal(&in_payload);
    match http_output {
        Ok(o) => {
            return HttpResponse::Ok()
                        .content_type("application/json")
                        .body( o );
        },
        Err(e) => {
            return HttpResponse::InternalServerError().body( e );
        },
    };
}

fn usage() {
    println!("Incomplete Worlds (c) 2020");
    println!("Flight Dynamics System (FDS) as a Service - HTTP API");
    println!("");
    println!("Usage:    main   config_file_name");
    println!("");
}



// ================================================================
// *
// *  M  A  I  N
// *
// ================================================================
#[actix_rt::main]
async fn main() -> std::io::Result<()> {     // -> Result<_, _> { // {
    let args: Vec<String> = env::args().collect();

    println!("Arguments: {:?}", args);

    if args.len() < 2 {
        usage();
        return Ok(());
    }
    
    let mut now: DateTime<Utc> = Utc::now(); 

    println!("**********************************");
    println!("Initializing FDS as a Service - HTTP API : {}", now.naive_utc() );
    println!("**********************************");

    // Load configuration file
    debug!("Reading the configuration file");
                
    let tmp_config_file_name = args[1].clone();
    let config_variables = read_config_json(&tmp_config_file_name);
    let config_variables = match config_variables {
        // Just return the variables
        Ok(tmp_variables) => tmp_variables,
        Err(tmp_error) => {
            println!("Unable to read the configuration file: {}", tmp_config_file_name.as_str() );
            println!("Error: {}", tmp_error);
            return Ok(());
        }
    };

    // Init Log
    let tmp_log_filename = config_variables.config_log_filename.clone();

    let error_code = config_log(&tmp_log_filename);
    if let Err(e) = error_code {
        println!("ERROR: Unable to read the Log Configuration file: {}", tmp_log_filename.as_str());
        println!("{} {}", e.to_string(), e);
        return Ok(());
    }

    info!("**********************************");
    info!("Initializing FDS as a Service - HTTP API : {}", now.naive_utc() );
    info!("**********************************");

    // External HTTP Address. It will listen for HTTP requests coming from this address
    let http_address = config_variables.fdsaas_http_address.clone();
   
    info!("Listening HTTP IP Address: {}", http_address);

    
    // Connect to the FDS server via Nanomsg 
    let internal_nng_address  = config_variables.fds_int_req_address.clone();

    info!("Nanomsg Internal Address: {}", internal_nng_address);
    
    unsafe {
        GLOBAL_DATA.fds_status      = EnumStatus::RUNNING;
        GLOBAL_DATA.nng_ip_address  = internal_nng_address.clone();
    }

    // Start http server in a separated thread
    // Channel for retrieving the http server variable
    let (tx, rx) = mpsc::channel();

    let http_thread = thread::spawn(move || {
        let sys = System::new("http-server");

        let srv = HttpServer::new(move || {
            App::new()
    
            // limit the maximum amount of data that server will accept
            .data(web::JsonConfig::default().limit( MAX_SIZE_JSON ))
    
            // Pass data to the handler. It makes a copy
            //.data(global_data.clone())

            .service(
                web::scope("/fdsaas")
                    .default_service(
                        web::route()
                        .to(|| HttpResponse::MethodNotAllowed()),
                    )

                    // .route("/", web::get().to( index ) )
                    // .route("/index.html", web::get().to( index ) )
                    .route("/api/exit", web::get().to(forward_message))


                    .route("/api/{operation}/usage", web::get().to(api_usage))

                    // REGISTER
                    // ---------------------------------
                    .route("/api/register", web::put().to(forward_message))

                    // GET VERSION
                    // ---------------------------------
                    .route("/api/version", web::get().to(get_version))

                    // GET STATUS
                    // ---------------------------------
                    .route("/api/status", web::get().to(get_status))

                    // Create a Mission
                    // ---------------------------------
                    .route("/api/create_mission", web::post().to(forward_message))

                    // Create a Satellite
                    // ---------------------------------
                    .route("/api/create_satellite", web::post().to(forward_message))

                    // Create a Ground Station
                    // ---------------------------------
                    .route("/api/create_ground_station", web::post().to(forward_message))

                    // PROPAGATE AN ORBIT
                    // ---------------------------------
                    .route("/api/orb_propagation", web::get().to(forward_message))
            )
            
            // Root URL
            // work, but serves only index.html
            .service( fs::Files::new("/", "WebContent").index_file("index.html") )
        })
        .bind(http_address)?
        .run();

        let _ = tx.send(srv);
        sys.run()
    });

    let srv = rx.recv().unwrap();

    let tmp_fds_bus_address = config_variables.fds_nng_bus_address.clone();

    let tmp_config_variables1 = config_variables.clone();
    let tmp_config_variables2 = config_variables.clone();

    // DBUS control loop
    let dbus_thread = thread::spawn(|| {
        dbus_control_loop(tmp_config_variables1, tmp_fds_bus_address);
    });
    
    // Main control loop thread
    let main_thread = thread::spawn(|| { 
        main_control_loop(tmp_config_variables2, internal_nng_address);
    }); 
    
    main_thread.join();
    dbus_thread.join();


    // pause accepting new connections
    //srv.pause().await;
    // resume accepting new connections
    //srv.resume().await;
    // Gratecul Stop of server
    srv.stop(true).await;

    now = Utc::now();
    info!("**********************************");
    info!("Finishing FDS Server: {}", now.naive_utc());   
    info!("**********************************");

    Ok(())
}
